import React from 'react'

const OrderUpdate = () => {
  return (
    <div class='order'>
      <h1>YOUR ORDER HAS BEEN PLACED...</h1> <br/>
      <h1>THANK YOU FOR SHOPPING :)</h1>
    </div>
  )
}

export default OrderUpdate
